// remoteProduct.ts
// This module exports a function that simulates a remote service to compute the product of two numbers.

/**
 * Simulates a remote service call to compute the product of two numbers.
 * @param {number} a - The first number.
 * @param {number} b - The second number.
 * @returns {Promise<number>} - The product of a and b.
 */
export default async function remoteProduct(a: number, b: number, noisy=false): Promise<number> {
  await new Promise(resolve => setTimeout(resolve, 80));

  const result = a * b;

  if (noisy) {
    // eslint-disable-next-line no-console
    console.log(`${a} * ${b} = ${result}`);
  }
  return result;
}

// function usageExample() {
//   remoteProduct(5, 7, true)
//       .then(product => console.log(`The product is: ${product}`))
//       .catch(e => console.error(e));
// }

// usageExample();
  