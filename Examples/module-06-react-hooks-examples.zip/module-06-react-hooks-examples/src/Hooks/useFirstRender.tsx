import { useEffect } from "react";

export function useFirstRender(action: () => void) {
  useEffect(() => {
    action();
  }, [action]);
}
