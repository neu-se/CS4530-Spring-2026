// Using a single eslint file in a multiple-workspaces setup means that the
// package.json that is visible from this config file has *no* registered
// dependencies or devDependencies. ESLint is right to complain about this!
// The next line says to ESLint: "don't worry, we know what we're doing,
// all the dependencies listed here are in `shared/package.json`."
/* eslint import/no-extraneous-dependencies: "off" */

import { defineConfig, globalIgnores } from 'eslint/config';
import js from '@eslint/js';
import tseslint from 'typescript-eslint';
import eslintPluginPrettierRecommended from 'eslint-plugin-prettier/recommended';
import eslintPluginImport from 'eslint-plugin-import';
import reactHooks from 'eslint-plugin-react-hooks';
import reactRefresh from 'eslint-plugin-react-refresh';

/**
 * We want @typescript-eslint/naming-convention to enforce different naming
 * naming conventions in React frontend code (which lives in the ./frontend or
 * ./client directory) and backend/other code. These are common naming
 * conventions between the two.
 */
const commonNamingConventions = [
  {
    // Variables are camelCase: `nimGameService`, `isDone`
    selector: ['variable', 'memberLike'],
    format: ['camelCase'],
    leadingUnderscore: 'allow',
  },
  {
    // Functions and methods too: `allGuessed`, `start`, `viewAs`, `isDone`
    selector: ['function', 'method'],
    format: ['camelCase'],
  },
  {
    // Types and class names are PascalCase: `GameService`, `NimState`
    selector: 'typeLike',
    format: ['PascalCase'],
  },
  {
    // Global constants are UPPER_CASE: `PORT`, `THREAD_API_URL`
    selector: 'variable',
    modifiers: ['global', 'const'],
    types: ['boolean', 'number', 'string', 'array'],
    format: ['UPPER_CASE'],
  },
  {
    // Private methods and fields must have a leading underscore: this._count
    selector: ['memberLike', 'method'],
    modifiers: ['private'],
    format: ['camelCase'],
    leadingUnderscore: 'require',
  },
];

export default defineConfig([
  globalIgnores([
    '**/build', // legacy output directory
    '**/dist', // vite's output directory
    '**/.stryker-tmp/', // stryker mutation reports
    '**/coverage', // istanbul coverage reports
    '**/playwright-report/', // playwright test reports
    '**/node_modules/**',
    '**/.next/**',
    '**/out/**',
    '*.config.js',
    '*.config.mjs',
  ]),
  {
    files: ['**/*.{js,mjs,cjs,ts,jsx,tsx}'],
    extends: [
      js.configs.recommended,
      eslintPluginImport.flatConfigs.recommended,
      eslintPluginImport.flatConfigs.typescript,
    ],
    settings: {
      'import/resolver': { typescript: true },
    },
    rules: {
      'eqeqeq': 'error',
      'import/no-amd': 'error',
      'import/no-commonjs': 'error',
      'import/no-empty-named-blocks': 'error',
      'import/no-extraneous-dependencies': [
        'error',
        {
          // devDependencies can be imported in config and test files
          devDependencies: [
            '**/*.config.mjs',
            '**/*.{spec,test}.{ts,tsx}',
            '**/tests/**/*.{ts,tsx}',
          ],
          includeInternal: true,
        },
      ],
      'import/no-import-module-exports': 'error',
      'import/no-named-as-default': 'error',
      'import/no-named-as-default-member': 'off',
      'no-param-reassign': 'error',
      'no-plusplus': 'error',
      'no-throw-literal': 'error',
      'no-unused-vars': ['error', { args: 'none', caughtErrors: 'none' }],
    },
  },
  {
    files: ['**/*.{ts,tsx}'],
    extends: tseslint.configs.recommendedTypeChecked,
    languageOptions: { parserOptions: { projectService: true } },
    rules: {
      '@typescript-eslint/naming-convention': [
        'error',
        ...commonNamingConventions,
        {
          // Keyv repository models are more like classes with static methods
          // than other constants, so this rule makes them PascalCase
          // (`GameRepo`) instead of the default camelCase.
          selector: 'variable',
          modifiers: ['global'],
          filter: { regex: 'Repo$', match: true },
          format: ['PascalCase'],
        },
      ],
      '@typescript-eslint/no-unused-vars': [
        'error',
        { args: 'none', varsIgnorePattern: '^_', caughtErrors: 'none' },
      ],
      '@typescript-eslint/no-misused-promises': [
        'error',
        {
          checksVoidReturn: {
            arguments: false,
            attributes: false,
          },
        },
      ],
      '@typescript-eslint/restrict-template-expressions': 'off',
      '@typescript-eslint/no-unsafe-member-access': ['error', { allowOptionalChaining: true }],
    },
  },
  {
    files: ['{client,frontend}/**/*.{ts,tsx}'],
    extends: [reactHooks.configs.flat.recommended, reactRefresh.configs.recommended],
    rules: {
      '@typescript-eslint/naming-convention': [
        'error',
        ...commonNamingConventions,
        {
          // React components want to be PascalCase: `AuthContext`, `ThreadPage`
          // Therefore, the camelCase-only restriction is relaxed for globals.
          selector: ['function', 'variable'],
          modifiers: ['global'],
          format: ['camelCase', 'PascalCase'],
        },
      ],
      // It is difficult to totally avoid floating promises in certain React
      // contexts, but they can nevertheless be a source of errors. We should
      // revisit this: it might be best to remove this exception or make it
      // merely a warning, which would require floating promises to be
      // explicitly marked with `void`.
      '@typescript-eslint/no-floating-promises': 'off',
    },
  },
  {
    // Test files may need to make use of the `any` type in a way we want to
    // prevent in normal code.
    files: ['**/*.{spec,test}.{ts,tsx}', '**/tests'],
    rules: {
      '@typescript-eslint/no-unsafe-assignment': 'off',
      '@typescript-eslint/no-unsafe-member-access': 'off',
      '@typescript-eslint/unbound-method': 'off',
    },
  },
  {
    extends: [eslintPluginPrettierRecommended],
    rules: { 'prettier/prettier': 'warn' },
  },
]);
