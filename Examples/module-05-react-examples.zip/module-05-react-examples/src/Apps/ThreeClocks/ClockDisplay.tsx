import { useState, useEffect } from 'react';
import { Box, Button, HStack } from '@chakra-ui/react';
import { type IClock } from '../../Interfaces/IClock.ts';

export type ClockDisplayProps = {
  name: string;
  clock: IClock;
};

export default function ClockDisplay(props: ClockDisplayProps) {
  const [localTime, setLocalTime] = useState(0);
  const incrementLocalTime = () => {
    setLocalTime(localTime => localTime + 1);
  };
  const clock = props.clock;

  useEffect(() => {
    const listener1 = () => {
      incrementLocalTime();
    };
    props.clock.addListener(listener1);
    console.log(`ClockDisplay ${props.name} is mounting`);
    return () => {
      console.log('ClockDisplay ' + props.name + ' is unmounting');
      props.clock.removeListener(listener1);
    };
  }, [props.clock, props.name]);

  return (
    <HStack>
      <Box>Clock: {props.name}</Box>
      <Box>Time = {localTime}</Box>
      <Box>nlisteners = {clock.nListeners}</Box>
      <Button aria-label={'start'} onClick={() => clock.start()}>
        Start
      </Button>
      <Button aria-label={'stop'} onClick={() => clock.stop()}>
        Stop
      </Button>
    </HStack>
  );
}
