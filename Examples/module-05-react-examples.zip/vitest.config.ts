/* eslint import/no-extraneous-dependencies: "off" */

import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['**/*.test.ts', '**/*.spec.ts'],
    exclude: ['node_modules/**'],
    coverage: { provider: 'istanbul' },
  },
});
