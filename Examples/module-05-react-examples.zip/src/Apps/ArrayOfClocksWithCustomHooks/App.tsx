import { Heading, Table, Tbody, VStack } from '@chakra-ui/react';
import { type ClockDisplayData, makeClockDisplay, makeTableRow } from './DisplayHelpers.tsx';
// import { type IClock } from '../../Interfaces/IClock.ts';

// import the custom hook
import useClockDisplayList from './useClockDisplayList original.ts';

export default function App() {
  const { handleAdd, handleDelete, clockDisplayData, clock } = useClockDisplayList();

  return (
    <VStack>
      <Heading>Array of Clock Displays (2024-09-26)</Heading>
      <Table>
        <Tbody>
          {clockDisplayData.map(
            (clockDisplayData: ClockDisplayData): JSX.Element =>
              makeTableRow(
                makeClockDisplay(clockDisplayData, clock, handleAdd, handleDelete),
                clockDisplayData.key,
              ),
          )}
        </Tbody>
      </Table>
    </VStack>
  );
}
