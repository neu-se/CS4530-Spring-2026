import { Heading, VStack } from '@chakra-ui/react';
import ClockDisplay from './ClockDisplay.tsx';
import SingletonClockFactory from '../../Classes/SingletonClockFactory.ts';

export default function App() {
  const clock = SingletonClockFactory.getInstance(1000);
  clock.start()

  return (
    <VStack>
      <Heading>Three Clocks</Heading>
      <ClockDisplay
        key={1}
        name={'Clock A'}
        clock={clock}
        />
      <ClockDisplay
        key={2}
        name={'Clock B'}
        clock={clock}
        />
      <ClockDisplay
        key={3}
        name={'Clock C'}
        clock={clock}
      />
    </VStack>
  );
}
