import { useState } from 'react';

export type UseEntryFormReturnValue = {
  handleTitleChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  handlePriorityChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  handleSubmit: (event: React.MouseEvent<HTMLButtonElement>) => void;
  getTitle: () => string;
  getPriority: () => string;
};
export default function useEntryForm(
  onAdd: (title: string, priority: string) => void,
): UseEntryFormReturnValue {
  // state variables for this form
  const [title, setTitle] = useState<string>('');
  const [priority, setPriority] = useState<string>('');
  const [key, setKey] = useState<number>(1); // key is assigned when the item is created.

  // the return type void is needed to keep eslint happy.
  function handleSubmit(event: React.MouseEvent<HTMLButtonElement>): void {
    event.preventDefault(); // magic, sorry.
    if (title === '') {
      return;
    } // ignore blank button presses
    onAdd(title, priority); // tell the parent about the new item
    setTitle(''); // resetting the values redisplays the placeholder
    setPriority(''); // resetting the values redisplays the placeholder
    setKey(key + 1); // increment the key for the next item
  }

  function handleTitleChange(event: React.ChangeEvent<HTMLInputElement>): void {
    setTitle(event.target.value);
    console.log('setting Title to:', event.target.value);
  }

  function handlePriorityChange(event: React.ChangeEvent<HTMLInputElement>): void {
    setPriority(event.target.value);
    console.log('setting Priority to:', event.target.value);
  }

  // return the current value of these fields
  function getTitle() {
    return title;
  }

  function getPriority() {
    return priority;
  }

  return {
    handleTitleChange: handleTitleChange,
    handlePriorityChange: handlePriorityChange,
    handleSubmit: handleSubmit,
    getTitle: getTitle,
    getPriority: getPriority,
  };
}
