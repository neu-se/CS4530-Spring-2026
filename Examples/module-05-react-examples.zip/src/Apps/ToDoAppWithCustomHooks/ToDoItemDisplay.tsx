import { IconButton, Tr, Td } from '@chakra-ui/react';
import { AiOutlineDelete } from 'react-icons/ai';

import { type ToDoItem } from './ToDoListTypes.ts';

export function ToDoItemDisplay(props: {
  item: ToDoItem;
  key: number;
  onDelete: (key: number) => void;
}) {
  // const [item, setItem] = useState(props.item)

  const item = props.item;

  function handleDelete() {
    console.log('deleting:', item);
    props.onDelete(item.key);
  }

  return (
    <Tr>
      <Td>{item.title}</Td>
      <Td>{item.priority}</Td>
      <Td>
        <ItemDeleteButton onClick={handleDelete} />
      </Td>
    </Tr>
  );
}

function ItemDeleteButton(props: { onClick: () => void }) {
  return <IconButton aria-label='delete' icon={<AiOutlineDelete />} onClick={props.onClick} />;
}
