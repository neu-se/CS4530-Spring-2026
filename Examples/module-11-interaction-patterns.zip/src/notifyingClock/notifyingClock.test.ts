import { describe, expect, test } from "vitest";
import { NotifyingClock } from "./notifyingClock.ts";
import { NotifyingClockClient } from "./notifyingClockClients.ts";

describe("tests of observed clock", () => {
  test("single observer", () => {
    const clock1 = new NotifyingClock();
    const observer1 = new NotifyingClockClient(clock1);
    expect(observer1.currentTime()).toBe(0);
    clock1.tick();
    clock1.tick();
    expect(observer1.currentTime()).toBe(2);
  });

  test("Multiple Observers", () => {
    const clock1 = new NotifyingClock();
    const observer1 = new NotifyingClockClient(clock1);
    const observer2 = new NotifyingClockClient(clock1);
    const observer3 = new NotifyingClockClient(clock1);
    clock1.tick();
    clock1.tick();
    expect(observer1.currentTime()).toBe(2);
    expect(observer2.currentTime()).toBe(2);
    expect(observer3.currentTime()).toBe(2);
  });
});
