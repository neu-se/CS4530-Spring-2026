import type { INotifyingClock, INotifyingClockClient } from "./INotifyingClock.ts";

export class NotifyingClockClient implements INotifyingClockClient {
  private _time: number;
  constructor(theClock: INotifyingClock) {
    this._time = theClock.currentTime();
    theClock.addClient(this);
  }

  onClockTick(time: number) {
    this._time = time;
  }

  currentTime(): number {
    return this._time;
  }
}
