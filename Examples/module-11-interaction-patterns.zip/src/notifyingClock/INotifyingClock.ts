export interface INotifyingClockClient {
  /** called when the clock ticks, with the new time */
  onClockTick(time: number): void;
}

export interface INotifyingClock {
  /** increments the time, notifies consumers of the new time */
  tick(): void;

  /** resets the time to 0 */
  reset(): void;

  /** returns the current time */
  currentTime(): number;

  /** adds a new consumer */
  addClient(client: INotifyingClockClient): void;
}
