import type { INotifyingClock, INotifyingClockClient } from "./INotifyingClock.ts";

export class NotifyingClock implements INotifyingClock {
  private _time = 0;
  private _observers: INotifyingClockClient[] = [];
  private _notifyAll() {
    this._observers.forEach((observer) => observer.onClockTick(this._time));
  }

  reset() {
    this._time = 0;
    this._notifyAll();
  }

  tick() {
    this._time += 1;
    this._notifyAll();
  }

  addClient(observer: INotifyingClockClient) {
    this._observers.push(observer);
  }

  currentTime() {
    return this._time;
  }
}
