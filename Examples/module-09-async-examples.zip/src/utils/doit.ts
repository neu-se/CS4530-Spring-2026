export default async function doit(thunk: () => any, n: number) : Promise<void> {
    for (let i = 0; i < n; i++) {
        console.log('---');
        await thunk();
    
    }
}
