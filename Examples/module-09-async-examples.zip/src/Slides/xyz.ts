import { myFetch } from './fakeRequest.ts';

async function X(n: number) {
  console.log(`X1 ${n}`);
  await Y(n);
  console.log(`X2 ${n}`);
  console.log('====');
}

async function Y(n: number) {
  console.log(`Y1 ${n}`);
  await Z(n);
  console.log(`Y2 ${n}`);
}

async function Z(n: number) {
  console.log(`Z1 ${n}`);
  await myFetch(`XYZ ${n}`);
  console.log(`Z2 ${n}`);
}

export default X;
