
import fakeRequest from './fakeRequest.ts'
import { beforeAll, describe, expect, test} from 'vitest'

// fakeRequest should make a network request using myFetch
// and then returns n + 1

describe('fakeRequest', () => {
    beforeAll(async() => {
        // dummy beforeAll to show how to use await in beforeAll
        // await fakeRequest(0)
    })

    test('fakeRequest should return its argument + 1 (await/expect)', async () => {
        expect.assertions(1)
        await expect(fakeRequest(100)).resolves.toEqual(101)
    })

    test('fakeRequest should return its argument + 1 (expect/await)', async () => {
        expect.assertions(1)
        expect(await fakeRequest(7)).toEqual(8)
    })

    test('should fail because wrong number of assertions', async () => {
        expect.assertions(3)
        await expect(fakeRequest(33)).resolves.toEqual(34)
    })
})
