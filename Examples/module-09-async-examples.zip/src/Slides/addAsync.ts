import myFetch from "./myFetch.ts";

export default async function addAsync(x: number, y: number): Promise<number> {
  await myFetch('addAsync');
  return x+y
}