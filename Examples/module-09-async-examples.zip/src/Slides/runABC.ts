import A from './abc.ts';

console.log("running runABC.ts")

void (await A(1));
