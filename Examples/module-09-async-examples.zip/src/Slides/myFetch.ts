export default function myFetch(name: string | number): Promise<Response> {
  console.log(`Promise created for ${name}`);
  return fetch(`https://google.com/`);
}