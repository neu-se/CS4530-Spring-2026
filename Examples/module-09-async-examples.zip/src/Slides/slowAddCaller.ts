import { slowAdd } from "./slowAdd.ts";

export async function slowAddCaller(x:number,y:number): Promise<number> {
    console.log(`SAC1 ${x},${y}`)
    const result : number = await slowAdd(x,y);
    console.log(`SAC2 ${result}`)
    return result;
}

void (await slowAddCaller(3,4));