import fakeRequest from "./fakeRequest.ts";

export async function makeRequest(requestNumber: number) {
    console.log(`starting makeRequest(${requestNumber})`);
    const response = await fakeRequest(requestNumber);
    console.log('request:', requestNumber, '\nresponse:', response);
}

