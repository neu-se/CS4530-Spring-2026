import A from './abc.ts';
import X from './xyz.ts';

// Run both A and X concurrently
// illustrates critical sections ABC and CBA always
// occur together without interleaving
// similarly for XYZ and ZYX.
// illustrates in-order creation
// non-deterministic completion order
// sometimes ends with ABC before XYZ,
// sometimes the reverse

await Promise.all([A(10), X(20)]);
