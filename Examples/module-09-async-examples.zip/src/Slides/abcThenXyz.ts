import A from './abc.ts';
import X from './xyz.ts';

// run A and X sequentially

async function main () {
    await A(10);
    console.log('>>>>>');
    await X(20);
}

void main()