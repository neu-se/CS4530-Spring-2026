import myFetch from "./myFetch.ts";

const log: string[] = [];

async function X(n: number) {
    await myFetch(1)
    log.push('X');
}

async function Y(n: number) {
    await myFetch(2)
    log.push('Y');
}

for (let i = 0; i < 4; i += 1) {
    log.push('start');
    await Promise.all([X(10), Y(20)]);
}
console.log(log);