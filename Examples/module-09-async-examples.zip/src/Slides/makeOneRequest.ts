import fakeRequest  from "./fakeRequest.ts";
import timeIt from "../utils/timeIt.ts";

export async function makeRequest(requestNumber: number) {
    console.log(`starting makeRequest(${requestNumber})`);
    const response = await fetch('https://google.com/');
    console.log(`received response for request ${requestNumber}`);
}

async function main() {
    console.log('starting main');
    await makeRequest(100);
    console.log('main finished');
}

timeIt(main);
