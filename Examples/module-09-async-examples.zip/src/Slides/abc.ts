import myFetch from './myFetch.ts';

async function A(n: number) {
  console.log(`A1 ${n}`);
  await B(n);
  console.log(`A2 ${n}`);
  console.log('====');
}

async function B(n: number) {
  console.log(`B1 ${n}`);
  await C(n);
  console.log(`B2 ${n}`);
}

async function C(n: number) {
  console.log(`C1 ${n}`);
  await myFetch(`ABC ${n}`);
  console.log(`C2 ${n}`);
}

export default A;
