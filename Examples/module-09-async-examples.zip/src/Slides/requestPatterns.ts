import timeit from "../utils/timeIt.ts";
import myFetch from "./myFetch.ts";


// }
// makes a network request, then returns requestNumber + 100
async function makeRequest(requestNumber:number) {
    console.log(`starting makeRequest(${requestNumber})`);
    await myFetch(`request ${requestNumber}`);
    const response = requestNumber + 100;
    console.log('request:', requestNumber, 'returned', response);
    return response
}

// make 3 concurrent requests using Promise.all
export async function make3ConcurrentRequests() {
    console.log('making 3 concurrent requests');
    const results = await Promise.all([
        makeRequest(1),
        makeRequest(2),
        makeRequest(3)
    ]);
    console.log('all 3 requests done, results:', results);
}

export async function make3SequentialRequests() {
    console.log('making 3 sequential requests');
    const result1 = await makeRequest(1);
    const result2 = await makeRequest(2);
    const result3 = await makeRequest(3);
    console.log('all 3 requests done, results:', [result1, result2, result3]);
}

export async function make3ChainedRequests() {
    console.log('making 3 chained requests');
    const result1 = await makeRequest(1);
    const result2 = await makeRequest(result1);
    const result3 = await makeRequest(result2);
    console.log('all 3 requests done, results:', [result1, result2, result3]);
}

// await timeit(make3ConcurrentRequests);
// await timeit(make3SequentialRequests);
await timeit(make3ChainedRequests);