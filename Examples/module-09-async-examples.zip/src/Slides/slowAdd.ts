import addAsync from "./addAsync.ts";

// addAsync returns a promise for the sum of x and y

async function slowAdd(x: number, y: number): Promise<number> {
    const p: Promise<number> = addAsync(x, y);
    const result: number = await p;
    return result;
}

export { slowAdd };