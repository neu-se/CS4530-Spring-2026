import myFetch from './myFetch.ts';

// fakeRequest makes a network request using myFetch
// and then returns n + 1
export default async function fakeRequest(n: number): Promise<number> {
  await myFetch(`fakeRequest ${n}`);
  return n + 1;
}