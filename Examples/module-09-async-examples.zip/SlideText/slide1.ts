type ordinaryType = (arg:number) => number;

type promiseType = (arg:number) => Promise<number>;
